<?php
include 'header.php';
include 'navbar.php';
include 'sidebar.php';
include 'content.php';
include 'footer.php';
?>